# grouplay-js
A client of turn-based game manager
